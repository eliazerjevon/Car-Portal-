package com.carportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarportalApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarportalApplication.class, args);
	}

}
